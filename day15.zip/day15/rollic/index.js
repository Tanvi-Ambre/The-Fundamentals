function rollic(...nums){
   let total = nums.reduce(function(init, v){
        return init + v;
   },0);
   return total;
};

module.exports = {
    rollic : rollic
}