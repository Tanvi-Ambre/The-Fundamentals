import { Component } from '@angular/core';
import { DataService } from './data.service';

@Component({
  selector: 'app-root',
  template : `
  <div class="container">
    <h1>{{ title }}</h1>
    <ol class="list-group">
      <li class="list-group-item" *ngFor="let hero of hlist">{{ hero }}</li>
    </ol>
    <hr>
    <input #ti type="text" name="heroname">
    <button (click)="addHeroHandler(ti.value)">Add New Hero</button>
  </div>
  `
})
export class AppComponent {
  title = 'Welcome to IBM India Angular Application';
  hlist;
  constructor(private ds:DataService){
    this.callDataServer();
  }
  callDataServer(){
    this.ds.getHeroList().subscribe( (res)=>{
      this.hlist = res;
    })
  }
  addHeroHandler(nhero){
    let resobj = {
      heroname : nhero
    }
    this.ds.postHeroList(resobj).subscribe((res)=>{
      console.log(res);
      this.hlist = res;
    })
  }
}
